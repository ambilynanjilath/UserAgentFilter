
#Package metadata
__version__='1.0.0'
__author__='Ambily Biju & Shahana Farvin'
__email__='ambilybiju2408@gmail.com ,shahana50997@gmail.com'

from .tester import UserAgentTester

__all__ = ['UserAgentFilter']



